/*******************************************************************************
The content of this file includes portions of the proprietary AUDIOKINETIC Wwise
Technology released in source code form as part of the game integration package.
The content of this file may not be used without valid licenses to the
AUDIOKINETIC Wwise Technology.
Note that the use of the game engine is subject to the Unity(R) Terms of
Service at https://unity3d.com/legal/terms-of-service
 
License Usage
 
Licensees holding valid licenses to the AUDIOKINETIC Wwise Technology may use
this file in accordance with the end user license agreement provided with the
software or, alternatively, in accordance with the terms contained
in a written agreement between you and Audiokinetic Inc.
Copyright (c) 2023 Audiokinetic Inc.
*******************************************************************************/

#include <sys/types.h>
#include <android/asset_manager_jni.h>
#include <android/asset_manager.h>
#include <jni.h>

extern CAkFilePackageLowLevelIOBlocking g_lowLevelIO;

namespace AkUnityAndroidSystem
{
	JavaVM* g_JavaVm = nullptr;
	jobject g_Activity = nullptr;
	AKRESULT InitAndroidSystem(jobject& out_jActivity)
	{	
		out_jActivity = nullptr;
		if (g_JavaVm == NULL)
		{
			return AK_NoJavaVM;
		}

		JNIEnv* lJNIEnv;
		g_JavaVm->GetEnv((void**)&lJNIEnv, JNI_VERSION_1_6);
		if(lJNIEnv == nullptr)
		{
			return AK_NoJavaVM;
		}
		
		jclass classActivity = lJNIEnv->FindClass("com/unity3d/player/UnityPlayer");
		if(classActivity == nullptr)
		{
			return AK_Fail;
		}

		jfieldID fieldActivity = lJNIEnv->GetStaticFieldID(classActivity, "currentActivity", "Landroid/app/Activity;");
		if(fieldActivity == nullptr)
		{
			return AK_Fail;
		}
		
		jobject ObjectField = lJNIEnv->GetStaticObjectField(classActivity, fieldActivity);
		if(ObjectField == nullptr)
		{
			return AK_Fail;
		}
		
		g_Activity = lJNIEnv->NewGlobalRef(ObjectField);
		g_lowLevelIO.Init(g_JavaVm, g_Activity);
		out_jActivity = g_Activity;
		return AK_Success;
	}

	AKRESULT TermAndroidSystem()
	{
		if (g_JavaVm == nullptr)
		{
			return AK_NoJavaVM;
		}

		JNIEnv* lJNIEnv;
		g_JavaVm->GetEnv((void**)&lJNIEnv, JNI_VERSION_1_6);
		if(lJNIEnv == nullptr)
		{
			return AK_NoJavaVM;
		}
		
		lJNIEnv->DeleteGlobalRef(g_Activity);
		g_Activity = nullptr;
		return AK_Success;
	}
};
jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
	AkUnityAndroidSystem::g_JavaVm = vm;
	return JNI_VERSION_1_6;		// minimum JNI version
}
